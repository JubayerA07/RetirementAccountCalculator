package RetirementAccountPackage;

/**
 * Thin entry point so teammates can keep a single {@code main} class if desired.
 */
public class Main {

    public static void main(String[] args) {
        MainApp.main(args);
    }
}
